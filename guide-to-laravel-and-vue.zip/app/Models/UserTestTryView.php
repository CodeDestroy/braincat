<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UserTestTryView extends Model
{
    use HasFactory;
    
    public $table = "user_test_try_view";
}
